//Funcion para agregar un renglon a la grilla y para cargar de datos a los combos
$(document).ready(function(){
    var productos;
    var clientes;
    $.ajax({
        type: 'GET',
        url: 'PodioServices.php?GetProductos',           
        success: function(data) {
            data = JSON.parse(data);
            for (i = 0; i < data.length; i++) { 
                    productos += '<option value= "'+data[i].Id+'">' + data[i].Descripcion + '</option>';
            }
            $('.selectpicker').selectpicker();
            $('#articulo0').html(productos).selectpicker('refresh');
        },
        async: false // <- this turns it into synchronous
    });

    $.ajax({
        type: 'GET',
        url: 'PodioServices.php?GetClientes',           
        success: function(data) {
            data = JSON.parse(data);
            for (i = 0; i < data.length; i++) { 
                    clientes += '<option value= "'+data[i].Id+'">' + data[i].Descripcion + '</option>';
            }
            $('.selectpicker').selectpicker();
            $('#clienteId').html(clientes).selectpicker('refresh');
        },
        async: false // <- this turns it into synchronous
    });

    var i=1;
    $("#add_row").click(function(e){
       e.preventDefault();

       $('#addr'+i).html("<td>"+ (i+1) +"</td><td style='display:none;'><input type='number' name='id"+i+"'  /></td><td><select class='form-control selectpicker' data-live-search='true' data-width='450px' name='articulo"+i+"' id='articulo"+i+"' placeholder='Artículo' ></select>  </td><td><input  name='talleColor"+i+"' type='text' class='form-control input-md' required></td><td><input  name='cantidad"+i+"' type='number' class='form-control input-md' required></td><td><input  name='precio"+i+"' type='number' min='1' step='any' class='form-control input-md'></td><td><input  name='cantidadxentrega"+i+"' type='text' class='form-control input-md'></td> <td><input type='number' name='cantidadEntregada"+i+"'  class='form-control'/></td><td><input type='text' name='nroFactura"+i+"'  class='form-control'/></td> ");

       $('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');


       $('.selectpicker').selectpicker();
       $('#articulo'+i).html(productos).selectpicker('refresh');

       i++; 
    });
    $("#delete_row").click(function(e){
            e.preventDefault();
             if(i>1){
             $("#addr"+(i-1)).html("");
             i--;
             }
    });


    var urlParams = new URLSearchParams(window.location.search);
    if(urlParams.has('id')) {
        var ordenDeCompraId = urlParams.get('id');
        
        $.ajax({
            type: 'GET',
            url: 'PodioServices.php?GetOrdenDeCompra',
            data: ({Id: ordenDeCompraId}),
            success: function(data) {
                data = JSON.parse(data);
                document.getElementById("IdDelPedido").value = data.IdDePedido;
                document.getElementById("clienteId").value = data.ClienteId;
                $('.selectpicker').selectpicker();
                $('#clienteId').html(clientes).selectpicker('val',data.ClienteId);
                document.getElementById("nroOC").value = data.NroOc;
                document.getElementById("lugarDeEntrega").value = data.LugarDeEntrega;
                document.getElementById("date").value = data.FechaDePrimeraEntrega;
                document.getElementById("tipoDeEntregaId").value = data.TipoDeEntrega;
                $('.selectpicker').selectpicker();
                $('#tipoDeEntregaId').selectpicker('val',data.TipoDeEntrega);
                document.getElementById("vendio").value = data.Vendio;
                document.getElementById("preparo").value = data.Preparo;
                data.Observaciones = data.Observaciones.replace('<p>','');
                data.Observaciones = data.Observaciones.replace('</p>','');
                document.getElementById("observaciones").value = data.Observaciones;
                
                //Elimino el primer row
                $("#addr0").html("");
                i--;

                //e.preventDefault();
                for (z = 0; z < data.Articulos.length; z++) { 
                    
                    $('#addr'+z).html("<td>"+ (z+1) +"</td><td style='display:none;'><input type='number' name='id"+z+"' value='"+data.Articulos[z].PedidoDeProductoId+"' /></td><td><select class='form-control selectpicker' data-live-search='true' data-width='450px' name='articulo"+z+"' id='articulo"+z+"' value='"+data.Articulos[z].ProductoId+"' placeholder='Artículo' ></select>  </td><td><input  name='talleColor"+z+"' value='"+data.Articulos[z].TalleColor+"' type='text' class='form-control input-md' required></td><td><input  name='cantidad"+i+"' value='"+parseInt(data.Articulos[z].Cantidad)+"' type='number' class='form-control input-md' required></td><td><input  name='precio"+z+"' value='"+data.Articulos[z].Precio+"' type='number' min='1' step='any' class='form-control input-md'></td><td><input  name='cantidadxentrega"+z+"' value='"+data.Articulos[z].CantidadXEntrega+"' type='text' class='form-control input-md'></td> <td><input type='number' name='cantidadEntregada"+z+"' value='"+data.Articulos[z].CantidadEntregada+"'  class='form-control'/></td><td><input type='text' name='nroFactura"+z+"'  value='"+ data.Articulos[z].NroFactura +"'  class='form-control'/></td> ");

                    $('#tab_logic').append('<tr id="addr'+(z+1)+'"></tr>');


                    $('.selectpicker').selectpicker();
                    $('#articulo'+z).html(productos).selectpicker('refresh');
                    $('#articulo'+z).html(productos).selectpicker('val',data.Articulos[z].ProductoId);
                    
                    i++;
                }
            },
            async: false // <- this turns it into synchronous
        });
    }
    
    
});
