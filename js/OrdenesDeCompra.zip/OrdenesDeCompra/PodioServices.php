<?php
$client_id = 'ordendecompra';
$client_secret = 'sd1eDVaKMw4K9iYSuaA4z7BlKeul4k8SfOszGFlQWJ7Fk1bz3m3v3eRsDJuPtLZm';

if(isset($_GET['GetOrdenDeCompra'])){
    require_once 'podio-php/PodioAPI.php';

    //App Orden de Compra
    $appOC_id = '20022554';
    $appOC_token = '9d837e1ae6224897b089c729382a9463';
    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($appOC_id, $appOC_token);
    
    
    $items = array();
    $ordenDeCompra =   PodioItem::get_by_app_item_id( $appOC_id, intval($_GET['Id']));
    $items['IdDePedido'] = PodioItem::get_field_value( $ordenDeCompra -> item_id, 168794396)[0]['value'];
    $items['ClienteId'] = PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590235)[0]['value']['item_id'];
    $items['NroOc'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590236)) > 0 ?  PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590236)[0]['value'] : '';
    $items['LugarDeEntrega'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590237)) > 0  ? PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590237)[0]['value'] : '';
    $items['FechaDePrimeraEntrega'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 166046557)) > 0  ? PodioItem::get_field_value( $ordenDeCompra -> item_id, 166046557)[0]['start_date'] : '';
    $items['TipoDeEntrega'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 166558798)) > 0  ? PodioItem::get_field_value( $ordenDeCompra -> item_id, 166558798)[0]['value'] : '';    
    $items['Vendio'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 166559385)) > 0 ? PodioItem::get_field_value( $ordenDeCompra -> item_id, 166559385)[0]['value'] : '';
    $items['Preparo'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590245)) > 0 ? PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590245)[0]['value']: '';
    $items['Observaciones'] = count(PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590242)) > 0 ? PodioItem::get_field_value( $ordenDeCompra -> item_id, 162590242)[0]['value'] : '' ;
    
    //App Pedidos de Productos
    $appPedido_id = '20040874';
    $appPedido_token = 'ce364c6c0be445d0a78076de2cf2dec3';
    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($appPedido_id, $appPedido_token);
    
    $detalles = PodioItem::get_field_value( $ordenDeCompra -> item_id, 162778362) ;
    $items['Articulos'] = array();
    foreach ($detalles as $detalle) {
        
        $articulo = array();
        $pedidoDeProducto = PodioItem::get_by_app_item_id( $appPedido_id, $detalle['value']['app_item_id']);
        $articulo['PedidoDeProductoId'] = $pedidoDeProducto -> item_id;
        $articulo['ProductoId'] = PodioItem::get_field_value( $pedidoDeProducto -> item_id, 168200140)[0]['value']['item_id'];
        $articulo['TalleColor'] = PodioItem::get_field_value( $pedidoDeProducto -> item_id, 164500992)[0]['value'];     
        $articulo['Cantidad'] = PodioItem::get_field_value( $pedidoDeProducto -> item_id, 162778358)[0]['value'];     
        $articulo['Precio'] = count(PodioItem::get_field_value( $pedidoDeProducto -> item_id, 162778359)) > 0  ? PodioItem::get_field_value( $pedidoDeProducto -> item_id, 162778359)[0]['value'] : '';      
        $articulo['CantidadXEntrega'] = count(PodioItem::get_field_value( $pedidoDeProducto -> item_id, 164671486)) > 0  ? PodioItem::get_field_value( $pedidoDeProducto -> item_id, 164671486)[0]['value'] : '';       
        $articulo['CantidadEntregada'] = count(PodioItem::get_field_value( $pedidoDeProducto -> item_id, 163045699)) > 0  ? PodioItem::get_field_value( $pedidoDeProducto -> item_id, 163045699)[0]['value'] : '';        
        $articulo['NroFactura'] = count(PodioItem::get_field_value( $pedidoDeProducto -> item_id, 164671485)) > 0  ? PodioItem::get_field_value( $pedidoDeProducto -> item_id, 164671485)[0]['value'] : '';    
        $items['Articulos'][] = $articulo;
    }
    
    echo  json_encode($items, JSON_UNESCAPED_UNICODE);	
}
if(isset($_GET['GetProductos']))
{
    //do something

    require_once 'podio-php/PodioAPI.php';

    //APP Producto
    $app_id = '20022555';
    $app_token = 'a12b1afd99374e669220495bc66b0928';
    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($app_id, $app_token);
    $collection = PodioItem::filter($app_id);
    $items = array();
    // Output the title of each item
    foreach ($collection as $item) {
        $attributes = array();
        $attributes['Id'] =  $item->item_id ;
        $attributes['Descripcion'] =  $item->title ;
        $items[] = $attributes;
    }
    
    echo json_encode($items, JSON_UNESCAPED_UNICODE);		
}


if(isset($_GET['GetClientes']))
{
    //do something

    require_once 'podio-php/PodioAPI.php';
    
    //APP Cliente
    $app_id = '20022559';
    $app_token = '96bd3d29940c48efbc9d7b8e2f53a003';
    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($app_id, $app_token);
    $collection = PodioItem::filter($app_id);
    $items = array();
    // Output the title of each item
    foreach ($collection as $item) {
        $attributes = array();
        $attributes['Id'] =  $item->item_id ;
        $attributes['Descripcion'] =  $item->title ;
        $items[] = $attributes;
    }
    
    echo json_encode($items, JSON_UNESCAPED_UNICODE);		
}
  


    
if(isset($_POST['submit']))
{
    require_once 'podio-php/PodioAPI.php';

    //App Orden de Compra
    $appOC_id = '20022554';
    $appOC_token = '9d837e1ae6224897b089c729382a9463';
    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($appOC_id, $appOC_token);

    if($_POST['IdDelPedido'] > 0){
        //Modifico Orden de Compra Cabecera
        $ordenVieja = PodioItem::get_by_app_item_id( $appOC_id, intval($_POST['IdDelPedido']));
        $ocNueva = PodioItem::update($ordenVieja-> item_id, array('fields' => array(
            "orden-de-compra" => $_POST['nroOC'] == "" ? null : $_POST['nroOC'],
            "cliente"=> intval($_POST['clienteId']),
            "lugar-de-entrega" => $_POST['lugarDeEntrega'] == "" ? null : $_POST['lugarDeEntrega'],
            "fecha-de-primera-entrega" => (string)$_POST['date'] == "" ? null : array('start' => (string)$_POST['date'] . ' 00:00:00' , "end" => null), 
            "fecha" => array('start' => date("Y-m-d H:i:s")  , "end" => null) ,
            "fecha-de-entrega" =>   date("Y-m-d H:i:s") ,
            "tipo-de-entrega" => $_POST['tipoDeEntregaId'] == "" ? null : $_POST['tipoDeEntregaId'], 
            "observaciones" => $_POST['observaciones'] == "" ? null : $_POST['observaciones'] ,
            "vendio-3" => $_POST['vendio'] == "" ? null : array('type' => 'work' , "value" => $_POST['vendio']),  
            "preparo" => $_POST['preparo'] == "" ? null : $_POST['preparo'] ,
            "fecha-primera-entrega-via-form" => (string)$_POST['date'] == "" ? null : date("d", strtotime($_POST['date'])),
            "mes-primera-entrega-via-form" => (string)$_POST['date'] == "" ? null : date("m", strtotime($_POST['date'])),
            "ano-primera-entrega-via-form" => (string)$_POST['date'] == "" ? null : date("y", strtotime($_POST['date'])),    
            //"link" => 'http://localhost/OrdenesDeCompra/Index.php?id='. $ordenVieja-> app_item_id ,
        )));
        $ocNueva = PodioItem::get_by_app_item_id( $appOC_id, $ordenVieja-> app_item_id);
    }else{
        //Creo Orden de Compra Cabecera
        $ocNueva = PodioItem::create($appOC_id, array('fields' => array(
            "orden-de-compra" => $_POST['nroOC'] == "" ? null : $_POST['nroOC'],
            "cliente"=> intval($_POST['clienteId']),
            "lugar-de-entrega" => $_POST['lugarDeEntrega'] == "" ? null : $_POST['lugarDeEntrega'],
            "fecha-de-primera-entrega" => (string)$_POST['date'] == "" ? null : array('start' => (string)$_POST['date'] . ' 00:00:00' , "end" => null), 
            "fecha" => array('start' => date("Y-m-d H:i:s")  , "end" => null) ,
            "fecha-de-entrega" =>   date("Y-m-d H:i:s") ,
            "tipo-de-entrega" => $_POST['tipoDeEntregaId'] == "" ? null : $_POST['tipoDeEntregaId'], 
            "observaciones" => $_POST['observaciones'] == "" ? null : $_POST['observaciones'] ,
            "vendio-3" => $_POST['vendio'] == "" ? null : array('type' => 'work' , "value" => $_POST['vendio']),  
            "preparo" => $_POST['preparo'] == "" ? null : $_POST['preparo'] ,
            "fecha-primera-entrega-via-form" => (string)$_POST['date'] == "" ? null : date("d", strtotime($_POST['date'])),
            "mes-primera-entrega-via-form" => (string)$_POST['date'] == "" ? null : date("m", strtotime($_POST['date'])),
            "ano-primera-entrega-via-form" => (string)$_POST['date'] == "" ? null : date("y", strtotime($_POST['date']))        
        )));
        
        /*PodioItem::update($ocNueva-> item_id, array('fields' => array(            
            "link" => 'http://localhost/OrdenesDeCompra/Index.php?id='. $ordenVieja-> app_item_id ,
        )));*/
    }
    
    
    
     //App Pedidos de Productos
    $appPedido_id = '20040874';
    $appPedido_token = 'ce364c6c0be445d0a78076de2cf2dec3';
    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($appPedido_id, $appPedido_token);
    
    $index = 0;
    $pedidosDeProductos;
    foreach ($_POST as $key => $value ) {
        if (strpos($key, 'articulo') !== false) {
            if($_POST['id' . strval($index)] > 0){
                //Modifico Pedidos de Productos
                $pedidoDeProducto = PodioItem::update(intval($_POST['id' . strval($index)]), array('fields' => array(
                    "id-de-pedido-2" => intval($ocNueva-> app_item_id) ,
                    "producto-3" => intval($_POST['articulo' . strval($index)]),
                    "talle-2"=> $_POST['talleColor' . strval($index)],
                    "cantidad" => intval($_POST['cantidad' . strval($index)]),
                    "precio-unitario" => (string)$_POST['precio' . strval($index)] == "" ? null : floatval($_POST['precio' . strval($index)]),
                    "cantidad-solicitada-x-entrega" => (string)$_POST['cantidadxentrega'. strval($index)] == "" ? null : intval($_POST['cantidadxentrega' . strval($index)]),
                    "cantidad-entregada" => (string)$_POST['cantidadEntregada'. strval($index)] == "" ? null : intval($_POST['cantidadEntregada' . strval($index)]),
                    "na-de-factura" => $_POST['nroFactura'. strval($index)] == "" ? null : $_POST['nroFactura' . strval($index)],
                    "oc" =>  intval($ocNueva-> item_id) ,
                )));
                
                $pedidosDeProductos[] = intval($_POST['id' . strval($index)]);

            }else{
                $pedidoDeProducto = PodioItem::create($appPedido_id, array('fields' => array(
                    "id-de-pedido-2" => intval($ocNueva-> app_item_id) ,
                    "producto-3" => intval($_POST['articulo' . strval($index)]),
                    "talle-2"=> $_POST['talleColor' . strval($index)],
                    "cantidad" => intval($_POST['cantidad' . strval($index)]),
                    "precio-unitario" => (string)$_POST['precio' . strval($index)] == "" ? null : floatval($_POST['precio' . strval($index)]),
                    "cantidad-solicitada-x-entrega" => (string)$_POST['cantidadxentrega'. strval($index)] == "" ? null : intval($_POST['cantidadxentrega' . strval($index)]),
                    "cantidad-entregada" => (string)$_POST['cantidadEntregada'. strval($index)] == "" ? null : intval($_POST['cantidadEntregada' . strval($index)]),
                    "na-de-factura" => $_POST['nroFactura'. strval($index)] == "" ? null : $_POST['nroFactura' . strval($index)],
                    "oc" =>  intval($ocNueva-> item_id) ,
                )));
                $pedidosDeProductos[] = $pedidoDeProducto-> item_id;
            }
            
            $index ++;
        }
    } 
    
     $ocNueva = PodioItem::update($ocNueva-> item_id, array('fields' => array(
            "productos-solicitados" => $pedidosDeProductos,
        )));
    
     header("Location: https://podio.com/innencomar/dimex-oc");
} 

?>